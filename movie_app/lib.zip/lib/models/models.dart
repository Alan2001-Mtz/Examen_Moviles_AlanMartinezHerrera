export 'package:movie_app/models/movie.dart';

