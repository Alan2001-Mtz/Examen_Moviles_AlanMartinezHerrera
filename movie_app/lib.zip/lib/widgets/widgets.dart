

export 'package:movie_app/widgets/custom_list_view.dart';

export 'package:movie_app/widgets/custom_card_widget.dart';
export 'package:movie_app/widgets/custom_swipper.dart';
