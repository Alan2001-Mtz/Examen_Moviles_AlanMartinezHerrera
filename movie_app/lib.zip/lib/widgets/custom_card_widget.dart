import 'package:flutter/material.dart';

class CustomCardImage extends StatelessWidget {
  const CustomCardImage({
    super.key, required this.posterPath,
  });

  final String posterPath;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: double.infinity,
      //color: Colors.amber,
      // para renderizar las imagenes
      child: FadeInImage(
        placeholder: AssetImage('assets/images/loading.gif'),
        image: AssetImage(posterPath),
      ),
    );
  }
}
