import 'package:flutter/material.dart';

class CustomListView extends StatelessWidget {
  const CustomListView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Text('Now Playing...',
          style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17,
          color: Colors.indigo),
          ),
        ),
        // ListView
        SizedBox(
          height: 180,
          width: double.infinity,
          
          child: ListView.builder(
            itemCount: 10,
            scrollDirection: Axis.horizontal,
            itemBuilder: (_ , i){
              //aqui se agrego el gesturedetector
              return GestureDetector(
                onTap: () => Navigator.pushNamed(context, 'details',arguments: 'movie $i'), // enviar la pelicula
                child: Container(
                  width: 120,
                  height: 180,
                  margin: EdgeInsets.all(10),
                  //color: Colors.deepOrange,
                  child: Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: FadeInImage(
                          height: 120,
                          placeholder: AssetImage('assets/images/loading.gif'),
                          // imagenes de la peli
                          image: NetworkImage('https://upload.wikimedia.org/wikipedia/commons/a/a3/Image-not-found.png'),
                          fit:BoxFit.cover
                        ),
                        
                      ),
                      Text('Titulo d Peli que sera muy largo', overflow: TextOverflow.ellipsis,maxLines: 2),
                    ],
                  ),
                ),
              );
            }
          ),
        )
      ],
    );
  }
}
