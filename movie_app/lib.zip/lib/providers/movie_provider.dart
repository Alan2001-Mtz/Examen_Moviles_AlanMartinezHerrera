import 'package:flutter/material.dart';
import 'package:movie_app/models/models.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;
import 'package:movie_app/models/movie_response.dart';

class MovieProvider extends ChangeNotifier {

  // https://api.themoviedb.org/3/movie/popular?api_key=b9aebfffc4d03a3ed592c36ece096062
  List<Movie> popularMovies = [];

  List<Movie> nowPlayingMovies = [];

  final urlm = 'api.themoviedb.org';
  final segmento = '/3/movie/popular';
  final api_key = 'b9aebfffc4d03a3ed592c36ece096062';

  MovieProvider() {
    getPopularMovies();
  }
 
  Future<String> getPopularMovies({String? seg}) async{
    // traer las peliculas
    final url = Uri.https(urlm, segmento, {'api_key': api_key});

    var response = await http.get(url);
    return response.body;
  }

  void getMoviesByPopular() async {
    final resp = await getPopularMovies();
    final data = convert.jsonDecode(resp) as Map<String,dynamic>;
    final popularResponse = MovieResponse.fromJson(data);
    //print(popularResponse.results[0].getPosterPath); // https://image.tmdb.org/t/p/w500/
    popularMovies = popularResponse.results;
    notifyListeners();
  }
}